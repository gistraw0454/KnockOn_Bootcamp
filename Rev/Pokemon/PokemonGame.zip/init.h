#ifndef INIT_H
#define INIT_H

#include "trainer.h"
#include "init.h"
#include "pokemon.h"

// 초기화 함수
void init(Trainer* trainer, Pokemon* Pokedex, int totalnum,int select);


#endif
